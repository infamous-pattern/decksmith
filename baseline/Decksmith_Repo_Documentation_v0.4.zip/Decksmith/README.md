# Decksmith

> **Open Control, Forged for Linux.**

> A polished, Linux-native control application for Elgato Stream Deck hardware, with the Stream Deck + as the reference device.

**Status:** Architecture frozen v0.4; ready for Phase 0 implementation  
**Reference platform:** Fedora Workstation 44, GNOME, Wayland  
**Reference hardware:** Elgato Stream Deck +  
**License:** To be finalized; Apache-2.0 is the current recommendation for original project code.

## Product intent

Decksmith is intended to be a first-class Linux desktop application, not a cross-platform application that merely happens to run on Linux. The product should provide a professional configuration experience, a reliable background daemon, deep Linux integrations, and optional compatibility with the open/unprotected portion of the Stream Deck plugin ecosystem.

Core principles:

- Linux first; Fedora is the reference distribution.
- GNOME/Wayland is a first-class target.
- Native GTK4/libadwaita UI.
- Rust for the daemon, device layer, Capability Engine, Context Engine, renderer, and most system integrations.
- SQLite for local configuration and state.
- Capability Engine for commands, adjustments, stateful controls, navigation, and dynamic providers.
- Profile -> Workspace -> Page hierarchy with Global/Profile/Workspace/Page binding scopes and temporary Context Layers.
- Customization-first renderer with panoramic key backgrounds, independent touch-strip backgrounds, themes, and per-control/state overrides.
- Behavior and appearance are independently portable/shareable.
- No cloud account, telemetry, or always-online dependency.
- Stream Deck + dials and touch strip are first-class capabilities.
- Deterministic Trigger Resolver supports short press, double press, long press, hold/repeat, raw press/release, dial-push gestures, and hardware touch gestures.
- VirtualDeck and hardware-in-loop testing are first-class engineering requirements.
- Session lock/idle behavior is explicit so programmable controls can be disabled, dimmed, or show an idle appearance safely.
- `decksmithd` starts automatically with the graphical user session by default; Decksmith Studio remains closed until requested.
- Quick access is always available while Decksmith is running: a native Decksmith GNOME panel indicator on the reference desktop and StatusNotifierItem integration on supporting desktops.
- Plugins are optional; core functionality must remain useful without them.
- Security boundaries and crash isolation are part of the product, not post-1.0 cleanup.

## Product naming

- **Decksmith** — project and product
- **Decksmith Studio** — GTK4/libadwaita configuration application
- **decksmithd** — background daemon
- **decksmithctl** — command-line interface
- **The Forge** — profile/theme/workflow creation area inside Decksmith Studio
- **Blueprints** — reusable profile/template packages
- **Decksmith Foundry** — future community catalog for plugins, themes, Blueprints, and related content
- **Tagline:** **Open Control, Forged for Linux.**

## Documentation

- [Product Requirements](docs/PRODUCT_REQUIREMENTS.md)
- [Technical Architecture](docs/TECHNICAL_ARCHITECTURE.md)
- [Repository and Release Strategy](docs/REPOSITORY_STRATEGY.md)
- [Architecture Decision Records](docs/adr/)

## Proposed repository layout

```text
.
├── apps/
│   ├── decksmith-studio/     # GTK4/libadwaita desktop app
│   ├── decksmith-daemon/           # systemd --user daemon
│   └── decksmith-cli/              # CLI for diagnostics and automation
├── crates/
│   ├── decksmith-core/                    # domain model, contexts, capability contracts
│   ├── decksmith-device/                  # Stream Deck device abstraction
│   ├── decksmith-render/                  # layered key/touch/customization rendering
│   ├── decksmith-store/                   # SQLite persistence and migrations
│   ├── decksmith-linux/                   # Linux-native integrations
│   ├── decksmith-ipc/                     # D-Bus interfaces and types
│   ├── decksmith-plugin-host/             # plugin lifecycle and compatibility host
│   └── decksmith-testkit/                 # mocks, fixtures, simulator helpers
├── extensions/
│   └── decksmith-gnome/             # Smart Profiles + GNOME panel indicator
├── packaging/
│   ├── fedora/                       # RPM spec and desktop integration
│   └── udev/                         # Stream Deck device access rules
├── plugins/
│   └── examples/                     # native/open plugin examples
├── tests/
│   ├── integration/
│   └── hardware-in-loop/
├── docs/
│   ├── adr/
│   ├── PRODUCT_REQUIREMENTS.md
│   ├── TECHNICAL_ARCHITECTURE.md
│   └── REPOSITORY_STRATEGY.md
├── scripts/
├── .github/                          # added when GitHub becomes canonical
├── Cargo.toml
├── deny.toml
├── rustfmt.toml
├── justfile
├── CONTRIBUTING.md
├── SECURITY.md
├── CODE_OF_CONDUCT.md
└── README.md
```

## External references

- Elgato Stream Deck +: https://www.elgato.com/us/en/p/stream-deck-plus
- Elgato Stream Deck downloads/software: https://www.elgato.com/us/en/s/downloads
- Elgato HID protocol: https://docs.elgato.com/streamdeck/hid/stream-deck-plus/
- Elgato Stream Deck SDK: https://docs.elgato.com/streamdeck/sdk/
- OpenDeck: https://github.com/nekename/OpenDeck
- Logitech MX Creative Console: https://www.logitech.com/en-us/shop/p/buy-mx-creative-console
- Loupedeck software: https://loupedeck.com/us/downloads/
- StreamController: https://github.com/StreamController/StreamController
- `elgato-streamdeck` Rust crate: https://docs.rs/elgato-streamdeck/latest/elgato_streamdeck/
